(** Total Hours worked on MS1 *)
let hours_worked = 20

open Board
open Command
open State
open Format
open Yojson.Basic.Util

(** The following are colors we will use in the board for each integer *)
let grey	s = "\027[1;30m" ^ s ^ "\027[0m"
let red	s = "\027[1;31m" ^ s ^ "\027[0m"
let green	s = "\027[1;32m" ^ s ^ "\027[0m"
let yellow	s = "\027[1;33m" ^ s ^ "\027[0m"
let blue s = "\027[1;34m" ^ s ^ "\027[0m"
let magenta	s = "\027[1;35m" ^ s ^ "\027[0m"
let cyan	s = "\027[1;36m" ^ s ^ "\027[0m"
let white	s = "\027[1;37m" ^ s ^ "\027[0m"

(** [get_num state s] returns the digit that is currently in the key [s] of the
    sudoku board in state [state]
    Requires:
      [state] is a valid state 
      [s] is a valid sudoku key *)
let get_num state s = 
  match get_box s (get_game state) with
  | Empty -> " "
  | Guess num -> white (string_of_int num)
  | Final num -> blue (string_of_int num)

(** [print_board state] prints out the current sudoku board.
    Requires:
      [state] is a valid state *)
let print_board state = "\027[1;34m    1   2   3   4   5   6   7   8   9
  \027[1;31m+-----------------------------------+
\027[1;34ma \027[1;31m|\027[0m "^get_num state "a1" ^" | "^get_num state "a2" ^" | "^get_num state "a3" ^" \027[1;31m|\027[0m "^get_num state "a4" ^" | "^get_num state "a5" ^" | "^get_num state "a6" ^" \027[1;31m|\027[0m "^get_num state "a7" ^" | "^get_num state "a8" ^" | "^get_num state "a9" ^" \027[1;31m|
  |\027[0m---+---+---\027[1;31m+\027[0m---+---+---\027[1;31m+\027[0m---+---+---\027[1;31m|
\027[1;34mb \027[1;31m|\027[0m "^get_num state "b1" ^" | "^get_num state "b2" ^" | "^get_num state "b3" ^" \027[1;31m|\027[0m "^get_num state "b4" ^" | "^get_num state "b5" ^" | "^get_num state "b6" ^" \027[1;31m|\027[0m "^get_num state "b7" ^" | "^get_num state "b8" ^" | "^get_num state "b9" ^" \027[1;31m|
  |\027[0m---+---+---\027[1;31m+\027[0m---+---+---\027[1;31m+\027[0m---+---+---\027[1;31m|
\027[1;34mc \027[1;31m|\027[0m "^get_num state "c1" ^" | "^get_num state "c2" ^" | "^get_num state "c3" ^" \027[1;31m|\027[0m "^get_num state "c4" ^" | "^get_num state "c5" ^" | "^get_num state "c6" ^" \027[1;31m|\027[0m "^get_num state "c7" ^" | "^get_num state "c8" ^" | "^get_num state "c9" ^" \027[1;31m|
  \027[1;31m|-----------+-----------+-----------|
\027[1;34md \027[1;31m|\027[0m "^get_num state "d1" ^" | "^get_num state "d2" ^" | "^get_num state "d3" ^" \027[1;31m|\027[0m "^get_num state "d4" ^" | "^get_num state "d5" ^" | "^get_num state "d6" ^" \027[1;31m|\027[0m "^get_num state "d7" ^" | "^get_num state "d8" ^" | "^get_num state "d9" ^" \027[1;31m|
  |\027[0m---+---+---\027[1;31m+\027[0m---+---+---\027[1;31m+\027[0m---+---+---\027[1;31m|
\027[1;34me \027[1;31m|\027[0m "^get_num state "e1" ^" | "^get_num state "e2" ^" | "^get_num state "e3" ^" \027[1;31m|\027[0m "^get_num state "e4" ^" | "^get_num state "e5" ^" | "^get_num state "e6" ^" \027[1;31m|\027[0m "^get_num state "e7" ^" | "^get_num state "e8" ^" | "^get_num state "e9" ^" \027[1;31m|
  |\027[0m---+---+---\027[1;31m+\027[0m---+---+---\027[1;31m+\027[0m---+---+---\027[1;31m|
\027[1;34mf \027[1;31m|\027[0m "^get_num state "f1" ^" | "^get_num state "f2" ^" | "^get_num state "f3" ^" \027[1;31m|\027[0m "^get_num state "f4" ^" | "^get_num state "f5" ^" | "^get_num state "f6" ^" \027[1;31m|\027[0m "^get_num state "f7" ^" | "^get_num state "f8" ^" | "^get_num state "f9" ^" \027[1;31m|
  \027[1;31m|-----------+-----------+-----------|
\027[1;34mg \027[1;31m|\027[0m "^get_num state "g1" ^" | "^get_num state "g2" ^" | "^get_num state "g3" ^" \027[1;31m|\027[0m "^get_num state "g4" ^" | "^get_num state "g5" ^" | "^get_num state "g6" ^" \027[1;31m|\027[0m "^get_num state "g7" ^" | "^get_num state "g8" ^" | "^get_num state "g9" ^" \027[1;31m|
  |\027[0m---+---+---\027[1;31m+\027[0m---+---+---\027[1;31m+\027[0m---+---+---\027[1;31m|
\027[1;34mh \027[1;31m|\027[0m "^get_num state "h1" ^" | "^get_num state "h2" ^" | "^get_num state "h3" ^" \027[1;31m|\027[0m "^get_num state "h4" ^" | "^get_num state "h5" ^" | "^get_num state "h6" ^" \027[1;31m|\027[0m "^get_num state "h7" ^" | "^get_num state "h8" ^" | "^get_num state "h9" ^" \027[1;31m|
  |\027[0m---+---+---\027[1;31m+\027[0m---+---+---\027[1;31m+\027[0m---+---+---\027[1;31m|
\027[1;34mi \027[1;31m|\027[0m "^get_num state "i1" ^" | "^get_num state "i2" ^" | "^get_num state "i3" ^" \027[1;31m|\027[0m "^get_num state "i4" ^" | "^get_num state "i5" ^" | "^get_num state "i6" ^" \027[1;31m|\027[0m "^get_num state "i7" ^" | "^get_num state "i8" ^" | "^get_num state "i9" ^" \027[1;31m|
  \027[1;31m+-----------------------------------+\027[0m
  "

(** [enter_command num_lst state] reads the key and value of [num_lst] and 
    carries out the move command to enter the value in the board.
    Requires:
      [board] is a valid Adventure
      [state] is a valid state *)
let enter_command num_lst state = 
  match num_lst with
  | [] -> Illegal
  | h::t -> let key = h in 
    match t with 
    | [] -> Illegal
    | h::t -> move key (int_of_string h) state


(** [read () board state] reads the input sentence and matches the command with
    Enter, Check, Quit, or exceptions. If Enter, run enter_command.
    Requires:
      [board] is a valid Adventure
      [state] is a valid state *)
let rec read () board state = 
  try let input = to_command (read_line ()) in
    match input with
    | Enter num -> enter_command num state
    | Check -> let checked = check_state board state in 
      if winner (checked_board checked) (get_answer board) then Winner
      else checked
    | Quit -> print_endline("Thank you for playing!"); exit 0
  with
  | Incorrect -> print_endline("Please enter a valid key and value");
    read () board state
  | Empty -> print_endline("Please enter a valid key and value");
    read () board state

(** [play_sudoku_helper board state] reads the input and matches with either 
    a Legal or Illegal command. If Legal, print the new board.
    If Illegal, print error message. Run till read quits.
    Requires:
      [board] is a valid Board
      [state] is a valid state *)
let rec play_sudoku_helper board state =
  let play = read () board state in 
  match play with
  | Legal s -> print_endline(print_board s);
    print_endline("Please enter a command: ");
    play_sudoku_helper board s
  | Illegal -> print_endline(print_board state);
    print_endline("Please enter a valid key and value: ");
    play_sudoku_helper board state
  | Winner -> print_endline(print_board state);
    print_endline("Congratulations! You have completed the puzzle!");
    exit 0

(** [play_sudoku f] starts the adventure in file [f]. *)
let play_sudoku f =
  let file = Yojson.Basic.from_file f in 
  let board = make_game file in 
  let state = init_state board in 
  print_endline(print_board state);
  print_endline ("\nUse the following commands to complete the puzzle:");
  print_endline ("  - enter (number) in (board position)
  - check
  - quit");
  print_endline ("Please enter a command: ");
  play_sudoku_helper board state


(** [game ()] prompts for the game to play, then starts it. *)
let game () =
  ANSITerminal.(print_string [blue]
                  "\n\nWelcome to Sudoku.\n");
  print_endline "Please enter the board you want.\n";
  match read_line () with
  | exception End_of_file -> ()
  | file_name -> play_sudoku file_name

(* Execute the game engine. *)
let () = game ()
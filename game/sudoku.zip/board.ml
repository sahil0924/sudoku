open Yojson.Basic.Util


type box = 
  | Guess of int
  | Final of int
  | Empty

(** The type representing a game board *)
type board = (string * box) list

type t = {
  puzzle: board;
  answer: board;
  description: string;
  difficulty: int
}

exception InvalidKey

(** [to_box num] initializes num in box form *)
let to_box (num: int) : box = 
  if num = 0 then Empty else Final num

(** [form_row json] is a list of integers from the given [json] file *)
let form_row json : int list = 
  json |> member "numbers" |> to_list |> List.map to_int

(**TODO *)
let to_board (lst : (int list) list) = 
  let rec helper l acc2 (row:char) (index:int) = 
    let key = (Char.escaped row) ^ (string_of_int index) in
    match l with 
    |[] -> acc2 
    |h::t -> helper t ((key, to_box h)::acc2) row (index+1) in 
  let rec parse_rows l acc2 (row:char) = 
    let code = Char.code row in
    match l with 
    |[] -> acc2 
    |h::t -> let a = helper h [] row 1 in 
      parse_rows t (a@acc2) (Char.chr (code+1)) in 
  parse_rows lst [] 'a'

let make_game json : t = {
  puzzle = json |> member "board" |> to_list |> List.map form_row |> to_board;
  answer = json |> member "key" |> to_list |> List.map form_row |> to_board;
  description = json |> member "description" |> to_string;
  difficulty = json |> member "difficulty" |> to_int;
}

let get_puzzle t  = t.puzzle

let get_answer t = t.answer

let get_box (key: string) (g : board) : box = 
  try List.assoc key g
  with Not_found -> raise InvalidKey

let set_box (k: string) (v:int) (d : board) = 
  try (k, Guess v):: List.remove_assoc k d
  with Not_found -> raise InvalidKey

let rec check (puzzle : board) (answer : board) = 
  match puzzle with
  | [] -> puzzle
  | (key, pint)::t -> match pint, (get_box key answer) with
    | Guess p, Final int -> if p = int 
      then (key, Final int) :: check (List.remove_assoc key puzzle) answer
      else (key, Guess p) :: check t answer
    | Final p, Final int -> (key, Final int) :: check (List.remove_assoc key puzzle) answer
    | Empty, Final int -> (key, Empty) :: check (List.remove_assoc key puzzle) answer
    | _ -> puzzle

let winner puzzle answer = 
  if (List.sort_uniq Stdlib.compare puzzle) =
     (List.sort_uniq Stdlib.compare answer) then true else false








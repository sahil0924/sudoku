open Board
open Command

type t = {
  game: Board.board;
  moves : int;
}

let init_state b = {
  game = get_puzzle b;
  moves = 0;
}

type result = 
  | Legal of t 
  | Illegal
  | Winner

let get_game t = t.game

let move (key : string) (v : int) (st : t) = 
  match (get_box key st.game) with
  | Final _ -> Illegal
  | _ -> Legal {game = set_box key v st.game; moves = st.moves + 1;}

let check_state board state = 
  let new_state = check state.game (get_answer board) in 
  Legal {game = new_state; moves = state.moves}

let checked_board result = 
  match result with
  | Legal t -> t.game
  | _ -> failwith("none")



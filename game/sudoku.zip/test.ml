open OUnit2
open Board
open State
open Command

(* Helper Functions  *)

(** [cmp_set_like_lists lst1 lst2] compares two lists to see whether
    they are equivalent set-like lists.  That means checking two things.
    First, they must both be {i set-like}, meaning that they do not
    contain any duplicates.  Second, they must contain the same elements,
    though not necessarily in the same order. *)
let cmp_set_like_lists lst1 lst2 =
  let uniq1 = List.sort_uniq compare lst1 in
  let uniq2 = List.sort_uniq compare lst2 in
  List.length lst1 = List.length uniq1 
  &&
  List.length lst2 = List.length uniq2
  &&
  uniq1 = uniq2

(** [make_lists_test name list1 list2] constructs an OUnit
    test named [name] that asserts set-like quality of [list1]
    with [list2]. *)
let make_lists_test 
    (name: string)
    (list1: ('a list))
    (list2: ('a list)) : test = 
  name >:: (fun _ -> 
      assert_equal ~cmp:cmp_set_like_lists 
        list1 list2)

(** json file from lonely_room.json *)
let j_1 = Yojson.Basic.from_file "b1.json"
(** Game 1 from j_1 *)
let g_1 = make_game j_1
let b_2 = set_box "g6" 5 (get_puzzle g_1)
let b_3 = set_box "g6" 9 b_2
let state_1 = init_state g_1



let test1 = [
  "get_box test1" >:: (fun _ ->  assert_equal (get_box "a4" (get_puzzle g_1)) (Final 4));
  "get_box test2" >:: (fun _ ->  assert_equal (get_box "g6" (get_puzzle g_1)) (Empty));
  "get_box test4" >:: (fun _ ->  assert_equal (get_box "g6" b_2) (Guess 5));
  "get_box test5" >:: (fun _ ->  assert_equal (get_box "g6" b_3) (Guess 9));
  "command_test1" >:: (fun _ ->  assert_equal (to_command "quit") (Quit));
  "command_test2" >:: (fun _ ->  assert_equal (to_command "check") (Check));
  "command_test3" >:: (fun _ ->  assert_raises (Incorrect)(fun () -> to_command "c") );
  "command_test4" >:: (fun _ ->  assert_raises (Empty)(fun () -> to_command "") );
  "command_test5" >:: (fun _ ->  assert_equal (to_command "enter 8 in A4") (Enter ["A4"; "8"]));
  "command_test6" >:: (fun _ ->  assert_raises (Incorrect)(fun () -> to_command "chfih") );
  "state_test1" >:: (fun _ ->  assert_equal (move "a1" 5 state_1) (Illegal));
  "state_test2" >:: (fun _ ->  assert_raises (InvalidKey)(fun () -> move "a0" 5 state_1) );
]

let test2= [make_lists_test "name" [] []
           ]

let test3 = [make_lists_test "name" [] []
            ]

let tests =
  "test suite for A1"  >::: List.flatten [
    test1;
    test2;
    test3;
  ]

let _ = run_test_tt_main tests